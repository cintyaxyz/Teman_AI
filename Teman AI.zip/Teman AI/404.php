<?php
/**
 * 404.php — Halaman Error 404 Not Found
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/nav_sidebar.php';
http_response_code(404);
$user = currentUser();
$homeUrl = getHomeDashboardUrl();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>404 — Halaman Tidak Ditemukan | Teman Warga AI</title>
<meta name="description" content="Halaman yang Anda cari tidak ditemukan di Teman Warga AI.">
<link rel="icon" type="image/svg+xml" href="logo.php"/>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script>
tailwind.config = {
  theme: { extend: { fontFamily: { sans: ['"Outfit"', 'sans-serif'] },
    colors: { brand: { 50:'#eff6ff',100:'#dbeafe',200:'#bfdbfe',300:'#93c5fd',400:'#60a5fa',500:'#3b82f6',600:'#2563eb',700:'#1d4ed8',800:'#1e40af',900:'#1e3a8a' } } } }
}
</script>
<style>
body { font-family: 'Outfit', sans-serif; }
@keyframes floatRobot { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-12px)} }
@keyframes blink { 0%,88%,100%{transform:scaleY(1)} 93%{transform:scaleY(0.08)} }
@keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
.robot-float { animation: floatRobot 3.5s ease-in-out infinite; }
.robot-eye   { transform-origin: center; animation: blink 3.5s infinite; }
.fade-up-1   { animation: fadeUp .6s ease both; }
.fade-up-2   { animation: fadeUp .6s .1s ease both; opacity:0; }
.fade-up-3   { animation: fadeUp .6s .2s ease both; opacity:0; }
</style>
</head>
<body class="bg-gradient-to-br from-slate-50 to-blue-50 min-h-screen flex items-center justify-center p-6 antialiased">
<div class="text-center max-w-lg mx-auto">
  <!-- Robot Illustration -->
  <div class="robot-float inline-block mb-6">
    <svg class="w-48 h-48 mx-auto drop-shadow-xl" fill="none" viewBox="0 0 320 320" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient cx="40%" cy="30%" id="rBG" r="65%">
          <stop offset="0%" stop-color="#FFFFFF"/>
          <stop offset="70%" stop-color="#F1F5F9"/>
          <stop offset="100%" stop-color="#CBD5E1"/>
        </radialGradient>
        <linearGradient id="rFace" x1="0%" x2="0%" y1="0%" y2="100%">
          <stop offset="0%" stop-color="#0F172A"/>
          <stop offset="100%" stop-color="#1E293B"/>
        </linearGradient>
      </defs>
      <!-- Antenna -->
      <rect fill="#94A3B8" height="20" rx="3" width="5" x="158" y="35"/>
      <circle cx="160" cy="32" fill="#EF4444" r="9"/>
      <circle class="animate-ping" cx="160" cy="32" fill="#FCA5A5" opacity="0.6" r="9" style="transform-origin:160px 32px;animation-duration:2s"/>
      <!-- Head -->
      <rect fill="#64748B" height="30" rx="6" width="12" x="68" y="100"/>
      <rect fill="#38BDF8" height="18" rx="2" width="5" x="72" y="106"/>
      <rect fill="#64748B" height="30" rx="6" width="12" x="240" y="100"/>
      <rect fill="#38BDF8" height="18" rx="2" width="5" x="244" y="106"/>
      <rect fill="url(#rBG)" height="118" rx="44" stroke="#E2E8F0" stroke-width="2" width="164" x="78" y="56"/>
      <rect fill="url(#rFace)" height="88" rx="28" width="126" x="97" y="72"/>
      <!-- Eyes (confused look) -->
      <g class="robot-eye">
        <!-- Left eye: sad -->
        <ellipse cx="130" cy="112" fill="#38BDF8" rx="13" ry="15"/>
        <ellipse cx="134" cy="108" fill="#FFFFFF" rx="4" ry="5"/>
        <line x1="118" y1="96" x2="130" y2="102" stroke="#EF4444" stroke-width="3" stroke-linecap="round"/>
        <!-- Right eye: sad -->
        <ellipse cx="190" cy="112" fill="#38BDF8" rx="13" ry="15"/>
        <ellipse cx="194" cy="108" fill="#FFFFFF" rx="4" ry="5"/>
        <line x1="202" y1="96" x2="190" y2="102" stroke="#EF4444" stroke-width="3" stroke-linecap="round"/>
      </g>
      <!-- Sad mouth -->
      <path d="M 148 138 Q 160 130 172 138" fill="none" stroke="#38BDF8" stroke-linecap="round" stroke-width="4"/>
      <!-- Question mark on chest -->
      <rect fill="url(#rBG)" height="90" rx="34" stroke="#E2E8F0" stroke-width="2" width="114" x="103" y="186"/>
      <text x="160" y="244" text-anchor="middle" font-size="32" font-weight="bold" fill="#0284C7">?</text>
      <!-- Arms -->
      <rect fill="url(#rBG)" height="16" rx="8" stroke="#CBD5E1" stroke-width="1.5" width="30" x="66" y="200"/>
      <circle cx="60" cy="196" fill="url(#rBG)" r="12" stroke="#CBD5E1" stroke-width="1.5"/>
      <rect fill="url(#rBG)" height="16" rx="8" stroke="#CBD5E1" stroke-width="1.5" width="30" x="224" y="200"/>
      <circle cx="260" cy="216" fill="url(#rBG)" r="12" stroke="#CBD5E1" stroke-width="1.5"/>
    </svg>
  </div>

  <!-- 404 Badge -->
  <div class="fade-up-1 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-red-50 border border-red-200 text-red-600 font-bold text-sm mb-4">
    <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
    Error 404 — Halaman Tidak Ditemukan
  </div>

  <h1 class="fade-up-2 text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight mb-3">
    Aduh, tersesat nih!
  </h1>
  <p class="fade-up-3 text-slate-500 text-base sm:text-lg leading-relaxed mb-8 max-w-sm mx-auto">
    Halaman yang Anda cari sepertinya sudah pindah, dihapus, atau memang tidak pernah ada. Maaf ya!
  </p>

  <!-- Action Buttons -->
  <div class="flex flex-col sm:flex-row items-center justify-center gap-3">
    <?php if (isLoggedIn()): ?>
    <a href="<?= htmlspecialchars($homeUrl); ?>" class="inline-flex items-center gap-2 px-6 py-3 bg-brand-600 hover:bg-brand-700 text-white font-semibold rounded-full shadow-lg shadow-brand-500/25 transition-all hover:-translate-y-0.5">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
      Kembali ke Dashboard
    </a>
    <?php else: ?>
    <a href="landing-page.php" class="inline-flex items-center gap-2 px-6 py-3 bg-brand-600 hover:bg-brand-700 text-white font-semibold rounded-full shadow-lg shadow-brand-500/25 transition-all hover:-translate-y-0.5">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
      Ke Halaman Utama
    </a>
    <?php endif; ?>
    <button onclick="history.back()" class="inline-flex items-center gap-2 px-6 py-3 bg-white hover:bg-slate-50 text-slate-700 font-semibold rounded-full border border-slate-200 hover:border-slate-300 shadow-sm transition-all">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg>
      Kembali
    </button>
  </div>

  <!-- Quick Links -->
  <div class="mt-10 pt-6 border-t border-slate-200">
    <p class="text-xs text-slate-400 font-medium uppercase tracking-wider mb-3">Mungkin Anda mencari:</p>
    <div class="flex flex-wrap items-center justify-center gap-2">
      <a href="buat_laporan_Masyarakat.php" class="px-3 py-1.5 rounded-full text-xs font-medium bg-white border border-slate-200 text-slate-600 hover:border-brand-400 hover:text-brand-600 transition-all">📣 Lapor Masalah</a>
      <a href="Ai_bot.php" class="px-3 py-1.5 rounded-full text-xs font-medium bg-white border border-slate-200 text-slate-600 hover:border-brand-400 hover:text-brand-600 transition-all">🤖 AI Chat</a>
      <a href="peta_laporan.php" class="px-3 py-1.5 rounded-full text-xs font-medium bg-white border border-slate-200 text-slate-600 hover:border-brand-400 hover:text-brand-600 transition-all">🗺️ Peta Laporan</a>
      <a href="forum_warga.php" class="px-3 py-1.5 rounded-full text-xs font-medium bg-white border border-slate-200 text-slate-600 hover:border-brand-400 hover:text-brand-600 transition-all">👥 Forum Warga</a>
    </div>
  </div>
</div>
</body>
</html>
