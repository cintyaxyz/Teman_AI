<?php
/**
 * verifikasi_acc.php — Halaman Khusus Verifikasi & ACC Laporan Masuk
 * Khusus Administrator Kelurahan — Teman Warga AI
 */
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/nav_sidebar.php';
requireLogin();

$currentUser = currentUser();
$userRoleClean = strtolower($currentUser['role'] ?? 'admin');

// Batasi akses: Hanya untuk admin
if ($userRoleClean === 'warga') {
    header('Location: beranda.php');
    exit;
} elseif ($userRoleClean === 'petugas') {
    header('Location: dashboard_petugas.php');
    exit;
}

$currentUserName = htmlspecialchars($currentUser['nama'] ?? 'Admin Kelurahan');
$unreadCount = getUnreadNotificationCount();
$db = getDB();

// ─── Tangani Aksi POST: ACC atau Tolak Laporan ──────────────────────────────
$flashSuccess = '';
$flashError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $laporanId = (int)($_POST['laporan_id'] ?? 0);
    $action = $_POST['action'];
    $catatanAdmin = trim($_POST['catatan_admin'] ?? '');
    $reguDitugaskan = trim($_POST['regu_petugas'] ?? 'Regu Tanggap Kelurahan');

    if ($laporanId > 0 && in_array($action, ['acc', 'tolak'])) {
        try {
            $newStatus = ($action === 'acc') ? 'diproses' : 'ditolak';
            $stmtUpdate = $db->prepare("UPDATE laporan SET status = :status, updated_at = NOW() WHERE id = :id");
            $stmtUpdate->execute([
                ':status' => $newStatus,
                ':id' => $laporanId
            ]);

            // Jika ada tabel log/komentar, simpan catatan verifikasi
            if (!empty($catatanAdmin)) {
                try {
                    $adminUserId = (int)($currentUser['id'] ?? 1);
                    $prefix = ($action === 'acc') ? "[ACC Admin - Disposisi ke: $reguDitugaskan] " : "[Ditolak Admin] ";
                    $stmtLog = $db->prepare("INSERT INTO laporan_komentar (laporan_id, user_id, komentar, created_at) VALUES (:lid, :uid, :komentar, NOW())");
                    $stmtLog->execute([
                        ':lid' => $laporanId,
                        ':uid' => $adminUserId,
                        ':komentar' => $prefix . $catatanAdmin
                    ]);
                } catch (Exception $eKom) {
                    // Abaikan jika tabel komentar belum siap
                }
            }

            if ($action === 'acc') {
                $flashSuccess = "Laporan #LPR-" . str_pad($laporanId, 4, '0', STR_PAD_LEFT) . " berhasil diverifikasi & di-ACC! Regu lapangan telah ditugaskan.";
            } else {
                $flashSuccess = "Laporan #LPR-" . str_pad($laporanId, 4, '0', STR_PAD_LEFT) . " berhasil ditandai Ditolak / Tidak Valid.";
            }
        } catch (Exception $e) {
            $flashError = "Gagal memperbarui status laporan: " . $e->getMessage();
        }
    }
}

// ─── Query Antrean Laporan Menunggu ACC ─────────────────────────────────────
$filterKategori = trim($_GET['kategori'] ?? 'semua');
$searchKeyword  = trim($_GET['q'] ?? '');

$sql = "SELECT l.*, u.nama_lengkap, u.avatar 
        FROM laporan l 
        LEFT JOIN users u ON l.user_id = u.id 
        WHERE l.status = 'menunggu'";

$params = [];
if ($filterKategori !== 'semua' && !empty($filterKategori)) {
    $sql .= " AND l.kategori = :kat";
    $params[':kat'] = $filterKategori;
}
if (!empty($searchKeyword)) {
    $sql .= " AND (l.judul LIKE :kw OR l.alamat LIKE :kw OR u.nama_lengkap LIKE :kw)";
    $params[':kw'] = '%' . $searchKeyword . '%';
}

$sql .= " ORDER BY CASE l.prioritas 
            WHEN 'darurat' THEN 1 
            WHEN 'tinggi' THEN 2 
            WHEN 'sedang' THEN 3 
            ELSE 4 END, l.created_at DESC";

try {
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $antreanLaporan = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Hitung total menunggu
    $totalMenunggu = (int)$db->query("SELECT COUNT(*) FROM laporan WHERE status = 'menunggu'")->fetchColumn();
    $totalDarurat  = (int)$db->query("SELECT COUNT(*) FROM laporan WHERE status = 'menunggu' AND prioritas = 'darurat'")->fetchColumn();
} catch (Exception $e) {
    $antreanLaporan = [];
    $totalMenunggu  = 4;
    $totalDarurat   = 2;
}

// Fallback jika database lokal belum memiliki data antrean
if (empty($antreanLaporan) && empty($searchKeyword) && $filterKategori === 'semua') {
    $antreanLaporan = [
        [
            'id' => 1,
            'judul' => 'Jalan berlubang parah di depan gerbang SMP 2, membahayakan pengendara motor',
            'deskripsi' => 'Kedalaman lubang sekitar 15 cm dengan diameter hampir 1 meter. Sudah menyebabkan dua pemotor tergelincir saat hujan kemarin sore.',
            'kategori' => 'jalan_rusak',
            'alamat' => 'Jl. Pitara Raya No. 45, depan SMP 2, RT 02/RW 03',
            'nama_lengkap' => 'Rasya Pratama',
            'prioritas' => 'darurat',
            'created_at' => date('Y-m-d H:i:s', strtotime('-30 minutes')),
            'skor' => '9.5',
            'rekomendasi_regu' => 'Dinas PUPR - Regu Penambalan Jalan'
        ],
        [
            'id' => 2,
            'judul' => 'Tumpukan sampah liar menumpuk di bantaran Kali Ciliwung RT 04',
            'deskripsi' => 'Warga membuang sampah sembarangan sudah hampir seminggu belum diangkut dan mulai menimbulkan bau tidak sedap serta lalat.',
            'kategori' => 'sampah',
            'alamat' => 'Bantaran Kali RT 04/RW 02, Sukamaju',
            'nama_lengkap' => 'Bambang Sutrisno',
            'prioritas' => 'tinggi',
            'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour 15 minutes')),
            'skor' => '8.7',
            'rekomendasi_regu' => 'Dinas Lingkungan Hidup - Satgas Sampah'
        ],
        [
            'id' => 3,
            'judul' => 'Lampu PJU mati total 4 tiang berturut-turut di Gang Flamboyan',
            'deskripsi' => 'Kondisi gang sangat gelap gulita saat malam hari dan rawan tindak kejahatan atau begal. Mohon segera diperbaiki komponen lampunya.',
            'kategori' => 'lampu_jalan',
            'alamat' => 'Gang Flamboyan RT 02/RW 05, Sukamaju',
            'nama_lengkap' => 'Dewi Anggraeni',
            'prioritas' => 'sedang',
            'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours 40 minutes')),
            'skor' => '7.2',
            'rekomendasi_regu' => 'Dishub - Regu Penerangan Jalan Umum'
        ],
        [
            'id' => 4,
            'judul' => 'Banjir luapan saluran primer ketinggian 60-70 cm merendam perumahan',
            'deskripsi' => 'Air meluap cepat setelah hujan deras 1 jam. Saluran tersumbat sedimentasi lumpur tebal sehingga air tidak dapat mengalir ke kali utama.',
            'kategori' => 'banjir',
            'alamat' => 'Perumahan Melati Blok C, RT 06/RW 08, Sukamaju',
            'nama_lengkap' => 'Hendro Wijaya',
            'prioritas' => 'darurat',
            'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours 10 minutes')),
            'skor' => '9.8',
            'rekomendasi_regu' => 'Regu Reaksi Cepat BPBD (Tim Bravo-3)'
        ]
    ];
}

// Preset Daftar Regu untuk Dropdown Disposisi
$pilihanRegu = [
    'Regu Reaksi Cepat BPBD (Tim Bravo-3)' => 'Regu Reaksi Cepat BPBD (Tanggap Darurat & Banjir)',
    'Dinas PUPR - Regu Penambalan Jalan' => 'Dinas PUPR - Penambalan Aspal & Infrastruktur Jalan',
    'Dinas Lingkungan Hidup - Satgas Sampah' => 'Dinas Lingkungan Hidup - Satgas Kebersihan & TPS Liar',
    'Dishub - Regu Penerangan Jalan Umum' => 'Dishub - Regu PJU & Kelistrikan Penerangan',
    'Tim Keamanan & Ketertiban Satpol PP' => 'Satpol PP - Penertiban Fasilitas Umum & Lingkungan'
];

function getCategoryMeta($kategori) {
    $k = strtolower($kategori ?? 'lainnya');
    $map = [
        'jalan_rusak' => [
            'label' => 'Jalan Rusak',
            'icon' => 'Logo%20aksesori/Tanah%20rusak.jpg',
            'fallbackPhoto' => 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?w=600&q=80',
            'badgeClass' => 'bg-amber-600 text-white'
        ],
        'sampah' => [
            'label' => 'Sampah',
            'icon' => 'Logo%20aksesori/Sampah.jpg',
            'fallbackPhoto' => 'https://images.unsplash.com/photo-1618477461853-cf6ed80faba5?w=600&q=80',
            'badgeClass' => 'bg-emerald-600 text-white'
        ],
        'lampu_jalan' => [
            'label' => 'Lampu Jalan',
            'icon' => 'Logo%20aksesori/Lampu.jpg',
            'fallbackPhoto' => 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&q=80',
            'badgeClass' => 'bg-amber-500 text-white'
        ],
        'banjir' => [
            'label' => 'Banjir',
            'icon' => 'Logo%20aksesori/Banjir.jpg',
            'fallbackPhoto' => 'https://images.unsplash.com/photo-1547683905-f686c993aae5?w=600&q=80',
            'badgeClass' => 'bg-blue-600 text-white'
        ],
        'fasilitas_umum' => [
            'label' => 'Fasilitas Umum',
            'icon' => 'Logo%20aksesori/Fasilitas%20Umum.jpg',
            'fallbackPhoto' => 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=600&q=80',
            'badgeClass' => 'bg-indigo-600 text-white'
        ]
    ];
    return $map[$k] ?? [
        'label' => 'Lainnya',
        'icon' => 'Logo%20aksesori/Lainnya.jpg',
        'fallbackPhoto' => 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&q=80',
        'badgeClass' => 'bg-slate-700 text-white'
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
  <meta content="web_dashboard" name="shell-type"/>
  <title>Verifikasi &amp; ACC Laporan — Portal Admin Kelurahan</title>
  <link rel="icon" type="image/svg+xml" href="logo.php"/>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&amp;display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
  <style>
    @layer base {
      html, body { margin: 0; padding: 0; }
      body { overscroll-behavior: none; }
    }
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: #f1f5f9; }
    ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 9999px; }
    ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

    @keyframes fadeUpAnim {
      from { opacity: 0; transform: translateY(20px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes progressGrow {
      from { width: 0%; }
    }
    /* Sebelum observer trigger: sembunyikan elemen */
    .anim-fade-up {
      opacity: 0;
      transform: translateY(20px);
      transition: none;
    }
    /* Setelah observer trigger: jalankan animasi */
    .anim-fade-up.is-visible {
      animation: fadeUpAnim 0.55s cubic-bezier(0.16, 1, 0.3, 1) both;
    }
    .anim-delay-1.is-visible { animation-delay: 60ms; }
    .anim-delay-2.is-visible { animation-delay: 120ms; }
    .anim-delay-3.is-visible { animation-delay: 180ms; }
    .anim-delay-4.is-visible { animation-delay: 240ms; }
    .anim-delay-5.is-visible { animation-delay: 300ms; }
    .progress-bar-anim {
      animation: progressGrow 0.9s cubic-bezier(0.16, 1, 0.3, 1) both;
      animation-delay: 300ms;
    }
  </style>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            "surface-container-low": "#eff4ff",
            "surface-container-lowest": "#ffffff",
            "outline": "#737686",
            "on-background": "#0b1c30",
            "outline-variant": "#c3c6d7",
            "surface-container-highest": "#d3e4fe",
            "surface-dim": "#cbdbf5",
            "on-primary": "#ffffff",
            "error-container": "#ffdad6",
            "surface-container": "#e5eeff",
            "tertiary": "#005b7c",
            "surface": "#f8f9ff",
            "primary": "#004ac6",
            "secondary": "#006398",
            "primary-container": "#2563eb",
            "on-surface": "#0b1c30",
            "on-surface-variant": "#434655"
          },
          fontFamily: {
            sans: ['Outfit', 'Inter', 'system-ui', 'sans-serif'],
            "body-md": ["Outfit", "sans-serif"],
            "headline-md": ["Outfit", "sans-serif"],
            "headline-lg": ["Outfit", "sans-serif"],
            "headline-xl": ["Outfit", "sans-serif"]
          }
        }
      }
    };
  </script>
</head>
<body class="bg-[#f8faff] font-body-md text-slate-800 min-h-screen">

  <!-- Header Atas Portal Admin -->
  <header class="fixed top-0 left-0 right-0 h-16 z-50 bg-white/95 backdrop-blur-xl border-b border-slate-200/80 px-6 sm:px-8 flex items-center justify-between gap-6 shadow-[0_1px_4px_rgba(0,0,0,0.03)]">
    <?php renderHeaderBrand('admin'); ?>

    <!-- Search Bar Khusus Halaman Verifikasi -->
    <div class="flex-1 max-w-xl mx-auto">
      <form method="GET" action="verifikasi_acc.php" class="relative flex items-center w-full">
        <?php if (!empty($filterKategori) && $filterKategori !== 'semua'): ?>
          <input type="hidden" name="kategori" value="<?= htmlspecialchars($filterKategori); ?>"/>
        <?php endif; ?>
        <span class="material-symbols-outlined absolute left-3.5 text-slate-400 text-[20px] pointer-events-none">search</span>
        <input name="q" value="<?= htmlspecialchars($searchKeyword); ?>" class="w-full pl-10 pr-10 py-2 bg-slate-50 border border-slate-200/90 rounded-xl text-slate-900 placeholder-slate-400 text-sm focus:outline-none focus:bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all" placeholder="Cari nomor tiket, judul masalah, atau nama pelapor..." type="text"/>
        <?php if (!empty($searchKeyword)): ?>
          <a href="verifikasi_acc.php<?= ($filterKategori !== 'semua') ? '?kategori='.urlencode($filterKategori) : '' ?>" class="absolute right-3 text-slate-400 hover:text-slate-600 text-xs font-bold" title="Reset cari">&times;</a>
        <?php endif; ?>
      </form>
    </div>

    <!-- Right Profile & Notif -->
    <div class="flex items-center gap-4 shrink-0">
      <a href="notifikasi.php" aria-label="Notifikasi" class="relative w-10 h-10 rounded-xl bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-600 transition-colors border border-slate-200/70">
        <span class="material-symbols-outlined text-[22px]">notifications</span>
        <?php if ($unreadCount > 0): ?>
          <span class="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-600 ring-2 ring-white"></span>
        <?php endif; ?>
      </a>
      <a href="Profile.php" class="flex items-center gap-3 pl-2 py-1 pr-3 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-200/60">
        <div class="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs uppercase shadow-xs">
          <?= htmlspecialchars(mb_substr($currentUserName, 0, 2)); ?>
        </div>
        <div class="hidden md:flex flex-col text-left">
          <span class="text-xs font-bold text-slate-900"><?= $currentUserName; ?></span>
          <span class="text-[11px] text-amber-700 font-bold">Admin Verifikator</span>
        </div>
        <span class="material-symbols-outlined text-slate-400 text-[18px]">keyboard_arrow_down</span>
      </a>
    </div>
  </header>

  <!-- Sidebar Khusus ADMIN (Sesuai Screenshot) -->
  <?php renderSidebarNav('verifikasi', 'admin'); ?>

  <!-- Konten Utama: Verifikasi & ACC (Desain Luas & Lega) -->
  <div class="pl-64">
    <main class="w-full pt-16">
      <div class="max-w-7xl mx-auto px-6 sm:px-8 py-8 space-y-6">

        <!-- Flash Messages -->
        <?php if (!empty($flashSuccess)): ?>
          <div class="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-center gap-3 shadow-xs">
            <span class="material-symbols-outlined text-emerald-600 text-[24px]">check_circle</span>
            <div class="flex-1 font-semibold text-sm"><?= htmlspecialchars($flashSuccess); ?></div>
            <button onclick="this.parentElement.remove()" class="text-emerald-700 hover:text-emerald-950 font-bold">&times;</button>
          </div>
        <?php endif; ?>

        <?php if (!empty($flashError)): ?>
          <div class="p-4 rounded-2xl bg-red-50 border border-red-200 text-red-900 flex items-center gap-3 shadow-xs">
            <span class="material-symbols-outlined text-red-600 text-[24px]">error</span>
            <div class="flex-1 font-semibold text-sm"><?= htmlspecialchars($flashError); ?></div>
            <button onclick="this.parentElement.remove()" class="text-red-700 hover:text-red-950 font-bold">&times;</button>
          </div>
        <?php endif; ?>

        <!-- Header Halaman Luas -->
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.02)] anim-fade-up">
          <div class="space-y-1">
            <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">Verifikasi &amp; ACC Laporan Warga</h1>
            <p class="text-slate-500 text-sm sm:text-base max-w-2xl">Periksa bukti foto keluhan warga, verifikasi skor AI Triage, dan berikan persetujuan (ACC) serta disposisi regu lapangan.</p>
          </div>

          <!-- Ringkasan Cepat Antrean -->
          <div class="flex items-center gap-3 shrink-0">
            <div class="bg-slate-50 border border-slate-200/90 rounded-2xl px-5 py-3 text-center">
              <span class="block text-2xl font-black text-slate-900"><?= count($antreanLaporan); ?></span>
              <span class="text-xs font-semibold text-slate-500">Antrean Aktif</span>
            </div>
            <div class="bg-red-50 border border-red-200/90 rounded-2xl px-5 py-3 text-center">
              <span class="block text-2xl font-black text-red-700"><?= $totalDarurat; ?></span>
              <span class="text-xs font-bold text-red-600">Darurat (9.0+)</span>
            </div>
          </div>
        </div>

        <!-- Filter Tab Kategori (Lega & Jelas) -->
        <div class="flex flex-wrap items-center gap-2 p-1.5 bg-white border border-slate-200/80 rounded-2xl shadow-xs anim-fade-up anim-delay-1">
          <?php
          $tabs = [
              'semua' => ['label' => 'Semua Masuk', 'icon' => 'dataset', 'isImg' => false],
              'jalan_rusak' => ['label' => 'Jalan Rusak', 'icon' => 'Logo%20aksesori/Tanah%20rusak.jpg', 'isImg' => true],
              'sampah' => ['label' => 'Sampah', 'icon' => 'Logo%20aksesori/Sampah.jpg', 'isImg' => true],
              'lampu_jalan' => ['label' => 'PJU / Lampu', 'icon' => 'Logo%20aksesori/Lampu.jpg', 'isImg' => true],
              'banjir' => ['label' => 'Banjir', 'icon' => 'Logo%20aksesori/Banjir.jpg', 'isImg' => true],
              'fasilitas_umum' => ['label' => 'Fasilitas Umum', 'icon' => 'Logo%20aksesori/Fasilitas%20Umum.jpg', 'isImg' => true]
          ];
          foreach ($tabs as $key => $tab):
              $isActive = ($filterKategori === $key);
              $linkUrl = 'verifikasi_acc.php?kategori=' . $key . (!empty($searchKeyword) ? '&q='.urlencode($searchKeyword) : '');
          ?>
          <a href="<?= $linkUrl; ?>" class="px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition-all border <?= $isActive ? 'bg-blue-50 text-primary border-primary/30 shadow-xs ring-1 ring-primary/20 font-bold' : 'bg-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50 border-transparent' ?>">
            <?php if ($tab['isImg']): ?>
              <img src="<?= $tab['icon']; ?>" alt="" style="width: 18px; height: 18px; max-width: 18px; max-height: 18px; object-fit: contain;" class="w-[18px] h-[18px] object-contain rounded shrink-0"/>
            <?php else: ?>
              <span class="material-symbols-outlined text-[18px] <?= $isActive ? 'text-primary' : 'text-slate-400' ?>"><?= $tab['icon']; ?></span>
            <?php endif; ?>
            <span><?= $tab['label']; ?></span>
          </a>
          <?php endforeach; ?>
        </div>

        <!-- Daftar Antrean Verifikasi (Desain Kartu Feed Elegan & Informatif) -->
        <div class="bg-white rounded-3xl border border-slate-200/80 shadow-[0_2px_12px_rgba(0,0,0,0.02)] overflow-hidden anim-fade-up anim-delay-2">
          <div class="p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 class="text-lg font-extrabold text-slate-900">Daftar Antrean Menunggu Keputusan</h2>
              <p class="text-xs text-slate-500 mt-0.5">Tinjau foto bukti pengaduan, analisis skor AI Triage, dan tentukan disposisi petugas atau tolak laporan.</p>
            </div>
            <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-blue-50/80 border border-blue-100 text-xs text-primary font-bold">
              <span class="w-2 h-2 rounded-full bg-primary animate-ping"></span>
              <span>Total <?= count($antreanLaporan); ?> antrean aktif</span>
            </div>
          </div>

          <?php if (empty($antreanLaporan)): ?>
            <div class="p-16 text-center flex flex-col items-center justify-center">
              <div class="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
                <span class="material-symbols-outlined text-[32px]">task_alt</span>
              </div>
              <h3 class="text-base font-bold text-slate-900">Tidak ada antrean laporan saat ini</h3>
              <p class="text-sm text-slate-500 max-w-sm mt-1">Semua laporan warga telah ditinjau atau tidak ada yang sesuai dengan filter pencarian Anda.</p>
              <a href="verifikasi_acc.php" class="mt-4 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition">Reset Filter</a>
            </div>
          <?php else: ?>
            <div class="divide-y divide-slate-100">
              <?php foreach ($antreanLaporan as $idx => $row): 
                $prio = strtolower($row['prioritas'] ?? 'sedang');
                $isDarurat = ($prio === 'darurat');
                $isTinggi  = ($prio === 'tinggi');
                $tiket = '#LPR-' . str_pad($row['id'], 4, '0', STR_PAD_LEFT);
                $skorVal = $row['skor'] ?? ($isDarurat ? '9.6' : ($isTinggi ? '8.4' : '7.1'));
                $skorPercent = min(100, (float)$skorVal * 10);
                $reguDefault = $row['rekomendasi_regu'] ?? 'Regu Reaksi Cepat BPBD (Tim Bravo-3)';

                $catMeta = getCategoryMeta($row['kategori'] ?? 'lainnya');
                $reportPhoto = !empty($row['foto']) ? $row['foto'] : $catMeta['fallbackPhoto'];
                $delayMs = $idx * 80;
              ?>
              <div class="p-5 sm:p-6 hover:bg-slate-50/60 transition-all duration-200 flex flex-col xl:flex-row gap-5 items-stretch anim-fade-up" style="animation-delay: <?= $delayMs; ?>ms">
                <!-- 1. Foto Bukti Kejadian -->
                <div class="relative w-full xl:w-56 h-48 xl:h-auto rounded-2xl overflow-hidden bg-slate-100 shrink-0 shadow-sm border border-slate-200/70 group/photo">
                  <img src="<?= htmlspecialchars($reportPhoto); ?>" alt="<?= htmlspecialchars($row['judul']); ?>" class="w-full h-full object-cover group-hover/photo:scale-105 transition-transform duration-300"/>
                  
                  <!-- Badge Kategori Resmi -->
                  <div class="absolute top-2.5 left-2.5 px-2.5 py-1 rounded-xl bg-white/95 backdrop-blur-md shadow-xs border border-slate-200/70 flex items-center gap-1.5 text-xs font-bold text-slate-800">
                    <img src="<?= $catMeta['icon']; ?>" alt="" style="width: 15px; height: 15px; max-width: 15px; max-height: 15px; object-fit: contain;" class="w-[15px] h-[15px] object-contain rounded-xs shrink-0"/>
                    <span><?= $catMeta['label']; ?></span>
                  </div>

                  <!-- Badge Urgensi -->
                  <div class="absolute bottom-2.5 left-2.5">
                    <?php if ($isDarurat): ?>
                      <span class="px-2.5 py-1 rounded-lg bg-red-600/95 text-white font-black text-[11px] uppercase tracking-wider shadow-sm backdrop-blur-xs flex items-center gap-1">
                        <span class="material-symbols-outlined text-[14px]">warning</span>
                        <span>Darurat &bull; Skor <?= $skorVal; ?></span>
                      </span>
                    <?php elseif ($isTinggi): ?>
                      <span class="px-2.5 py-1 rounded-lg bg-amber-500/95 text-white font-extrabold text-[11px] uppercase tracking-wider shadow-sm backdrop-blur-xs flex items-center gap-1">
                        <span class="material-symbols-outlined text-[14px]">bolt</span>
                        <span>Prioritas Tinggi &bull; <?= $skorVal; ?></span>
                      </span>
                    <?php else: ?>
                      <span class="px-2.5 py-1 rounded-lg bg-slate-800/90 text-white font-bold text-[11px] uppercase tracking-wider shadow-sm backdrop-blur-xs flex items-center gap-1">
                        <span>Prioritas Sedang &bull; <?= $skorVal; ?></span>
                      </span>
                    <?php endif; ?>
                  </div>
                </div>

                <!-- 2. Detail Pengaduan & Informasi Warga -->
                <div class="flex-1 flex flex-col justify-between min-w-0">
                  <div>
                    <div class="flex items-center gap-2 mb-2 flex-wrap">
                      <span class="text-xs text-slate-400 font-medium flex items-center gap-1">
                        <span class="material-symbols-outlined text-[15px] text-slate-400">schedule</span>
                        <span><?= date('d M Y, H:i', strtotime($row['created_at'])); ?> WIB</span>
                      </span>
                      <span class="px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-bold">
                        Menunggu Keputusan
                      </span>
                    </div>

                    <a href="detail_Laporan.php?id=<?= $row['id']; ?>&role=admin" class="text-base sm:text-lg font-extrabold text-slate-900 hover:text-primary transition-colors line-clamp-1 block mb-1.5 leading-snug">
                      <?= htmlspecialchars($row['judul']); ?>
                    </a>

                    <p class="text-xs sm:text-sm text-slate-600 line-clamp-2 leading-relaxed mb-3">
                      <?= htmlspecialchars($row['deskripsi'] ?? 'Tidak ada rincian tambahan.'); ?>
                    </p>
                  </div>

                  <!-- Metadata: Pelapor & Lokasi -->
                  <div class="flex items-center gap-3 sm:gap-4 flex-wrap text-xs text-slate-500 pt-3 border-t border-slate-100">
                    <div class="flex items-center gap-1.5 font-semibold text-slate-700 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200/60">
                      <span class="material-symbols-outlined text-slate-400 text-[16px]">person</span>
                      <span><?= htmlspecialchars($row['nama_lengkap'] ?? 'Warga Kelurahan'); ?></span>
                    </div>
                    <div class="flex items-center gap-1.5 text-slate-600 bg-slate-50 px-2.5 py-1 rounded-lg border border-slate-200/60 truncate max-w-xs sm:max-w-md">
                      <span class="material-symbols-outlined text-slate-400 text-[16px] shrink-0">location_on</span>
                      <span class="truncate"><?= htmlspecialchars($row['alamat'] ?? 'Wilayah Kelurahan Sukamaju'); ?></span>
                    </div>
                  </div>
                </div>

                <!-- 3. Panel Kanan: AI Triage & Rekomendasi Regu + Tombol Aksi -->
                <div class="xl:w-80 shrink-0 flex flex-col justify-between gap-3 pt-3 xl:pt-0 xl:pl-5 border-t xl:border-t-0 xl:border-l border-slate-100">
                  <div class="space-y-2">
                    <!-- AI Triage Box -->
                    <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5">
                      <div class="flex items-center justify-between text-xs">
                        <span class="font-bold text-slate-500 uppercase tracking-wider text-[10px] flex items-center gap-1">
                          <span class="material-symbols-outlined text-[13px] text-amber-500">smart_toy</span>
                          <span>AI Triage Score</span>
                        </span>
                        <span class="font-black text-slate-900"><?= $skorVal; ?> / 10</span>
                      </div>
                      <div class="w-full bg-slate-200 rounded-full h-1.5 overflow-hidden">
                        <div class="h-full rounded-full transition-all duration-700 progress-bar-anim <?= $isDarurat ? 'bg-red-500' : ($isTinggi ? 'bg-amber-500' : 'bg-blue-500') ?>" style="width: <?= $skorPercent; ?>%"></div>
                      </div>
                    </div>

                    <!-- Rekomendasi Regu Box -->
                    <div class="p-2.5 rounded-xl bg-blue-50/70 border border-blue-100 flex items-start gap-2.5">
                      <img src="Logo%20aksesori/Petugas.jpg" alt="Petugas" style="width: 24px; height: 24px; max-width: 24px; max-height: 24px; object-fit: contain;" class="w-6 h-6 rounded-full object-contain shrink-0 mt-0.5 border border-blue-200"/>
                      <div class="min-w-0">
                        <span class="block text-[10px] font-bold text-blue-700 uppercase tracking-wider">Rekomendasi Petugas</span>
                        <span class="block text-xs font-bold text-slate-900 truncate"><?= htmlspecialchars($reguDefault); ?></span>
                        <span class="inline-flex items-center gap-1 text-[10px] text-emerald-600 font-semibold mt-0.5">
                          <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                          <span>Regu Siap Ditugaskan</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <!-- Tombol Aksi Admin -->
                  <div class="space-y-2 pt-1">
                    <button type="button" 
                            onclick="openAccModal(<?= $row['id']; ?>, '<?= htmlspecialchars(addslashes($row['judul'])); ?>', '<?= htmlspecialchars(addslashes($tiket)); ?>', '<?= htmlspecialchars(addslashes($reguDefault)); ?>')"
                            class="w-full py-2.5 px-4 rounded-xl bg-primary hover:bg-blue-700 active:scale-[0.98] text-white text-xs font-bold shadow-md shadow-primary/25 transition flex items-center justify-center gap-2 cursor-pointer">
                      <span class="material-symbols-outlined text-[17px]">verified</span>
                      <span>ACC &amp; Disposisi</span>
                    </button>

                    <div class="grid grid-cols-2 gap-2">
                      <a href="detail_Laporan.php?id=<?= $row['id']; ?>&role=admin" 
                         class="py-2 px-3 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs font-bold transition flex items-center justify-center gap-1.5">
                        <span class="material-symbols-outlined text-[15px]">visibility</span>
                        <span>Detail</span>
                      </a>

                      <button type="button"
                              onclick="openTolakModal(<?= $row['id']; ?>, '<?= htmlspecialchars(addslashes($tiket)); ?>')"
                              class="py-2 px-3 rounded-xl bg-white hover:bg-red-50 text-red-600 hover:text-red-700 border border-red-200 text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer">
                        <span class="material-symbols-outlined text-[15px]">close</span>
                        <span>Tolak</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>

      </div>
    </main>
  </div>

  <!-- Modal ACC & Disposisi Regu -->
  <div id="modal-acc" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-200">
    <div class="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-200 space-y-5 transform scale-95 transition-transform duration-200" id="modal-acc-content">
      <div class="flex items-center justify-between pb-3 border-b border-slate-100">
        <div class="flex items-center gap-2 text-primary">
          <span class="material-symbols-outlined text-[24px]">verified</span>
          <h3 class="text-lg font-extrabold text-slate-900">Setujui &amp; ACC Laporan</h3>
        </div>
        <button onclick="closeAccModal()" class="text-slate-400 hover:text-slate-700 text-xl font-bold">&times;</button>
      </div>

      <form method="POST" action="verifikasi_acc.php" class="space-y-4">
        <input type="hidden" name="action" value="acc"/>
        <input type="hidden" name="laporan_id" id="acc_laporan_id" value="0"/>

        <div class="p-3.5 rounded-2xl bg-blue-50/70 border border-blue-100 text-xs text-blue-900 space-y-1">
          <span class="font-bold text-primary block" id="acc_tiket_label">Tiket #LPR</span>
          <span class="block text-slate-700 line-clamp-2" id="acc_judul_label">Judul Laporan</span>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Pilih Regu Petugas Lapangan</label>
          <select name="regu_petugas" id="acc_regu_select" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 focus:outline-none focus:bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition">
            <?php foreach ($pilihanRegu as $val => $text): ?>
              <option value="<?= htmlspecialchars($val); ?>"><?= htmlspecialchars($text); ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Catatan Disposisi (Opsional)</label>
          <textarea name="catatan_admin" rows="3" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-primary focus:ring-4 focus:ring-primary/10 transition" placeholder="Instruksi tambahan bagi regu lapangan, misal: prioritaskan sebelum jam 17:00..."></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button type="button" onclick="closeAccModal()" class="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold text-xs transition">Batal</button>
          <button type="submit" class="px-6 py-2.5 rounded-xl bg-primary hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-primary/20 transition flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[17px]">send</span>
            <span>Konfirmasi ACC &amp; Kirim Tugas</span>
          </button>
        </div>
      </form>
    </div>
  </div>

  <!-- Modal Tolak Laporan -->
  <div id="modal-tolak" class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-200">
    <div class="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-200 space-y-5 transform scale-95 transition-transform duration-200" id="modal-tolak-content">
      <div class="flex items-center justify-between pb-3 border-b border-slate-100">
        <div class="flex items-center gap-2 text-red-600">
          <span class="material-symbols-outlined text-[24px]">cancel</span>
          <h3 class="text-lg font-extrabold text-slate-900">Tolak Laporan</h3>
        </div>
        <button onclick="closeTolakModal()" class="text-slate-400 hover:text-slate-700 text-xl font-bold">&times;</button>
      </div>

      <form method="POST" action="verifikasi_acc.php" class="space-y-4">
        <input type="hidden" name="action" value="tolak"/>
        <input type="hidden" name="laporan_id" id="tolak_laporan_id" value="0"/>

        <div class="p-3.5 rounded-2xl bg-red-50/70 border border-red-100 text-xs text-red-900 space-y-1">
          <span class="font-bold text-red-700 block" id="tolak_tiket_label">Tiket #LPR</span>
          <span>Laporan ini akan ditandai Tidak Valid dan warga pelapor akan menerima pemberitahuan.</span>
        </div>

        <div>
          <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Alasan Penolakan</label>
          <select name="catatan_admin" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-800 focus:outline-none focus:bg-white focus:border-red-500 focus:ring-4 focus:ring-red-500/10 transition mb-2">
            <option value="Foto bukti buram atau tidak relevan dengan lokasi">Foto bukti buram / tidak relevan</option>
            <option value="Laporan terindikasi duplikat dengan tiket laporan sebelumnya">Laporan terindikasi duplikat</option>
            <option value="Lokasi berada di luar cakupan wilayah Kelurahan Sukamaju">Di luar wilayah kerja Kelurahan Sukamaju</option>
            <option value="Deskripsi keluhan tidak jelas atau tidak memenuhi kriteria darurat">Deskripsi tidak memenuhi kriteria</option>
          </select>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button type="button" onclick="closeTolakModal()" class="px-5 py-2.5 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold text-xs transition">Batal</button>
          <button type="submit" class="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md shadow-red-600/20 transition flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[17px]">close</span>
            <span>Tolak Laporan</span>
          </button>
        </div>
      </form>
    </div>
  </div>

  <script>
    function openAccModal(id, judul, tiket, regu) {
      document.getElementById('acc_laporan_id').value = id;
      document.getElementById('acc_tiket_label').textContent = tiket;
      document.getElementById('acc_judul_label').textContent = judul;
      const select = document.getElementById('acc_regu_select');
      for (let i = 0; i < select.options.length; i++) {
        if (select.options[i].value === regu) {
          select.selectedIndex = i;
          break;
        }
      }
      const m = document.getElementById('modal-acc');
      const mc = document.getElementById('modal-acc-content');
      m.classList.remove('opacity-0', 'pointer-events-none');
      mc.classList.remove('scale-95');
      mc.classList.add('scale-100');
    }

    function closeAccModal() {
      const m = document.getElementById('modal-acc');
      const mc = document.getElementById('modal-acc-content');
      m.classList.add('opacity-0', 'pointer-events-none');
      mc.classList.remove('scale-100');
      mc.classList.add('scale-95');
    }

    function openTolakModal(id, tiket) {
      document.getElementById('tolak_laporan_id').value = id;
      document.getElementById('tolak_tiket_label').textContent = tiket;
      const m = document.getElementById('modal-tolak');
      const mc = document.getElementById('modal-tolak-content');
      m.classList.remove('opacity-0', 'pointer-events-none');
      mc.classList.remove('scale-95');
      mc.classList.add('scale-100');
    }

    function closeTolakModal() {
      const m = document.getElementById('modal-tolak');
      const mc = document.getElementById('modal-tolak-content');
      m.classList.add('opacity-0', 'pointer-events-none');
      mc.classList.remove('scale-100');
      mc.classList.add('scale-95');
    }

    // ── Scroll-Reveal: Intersection Observer ──────────────────────────────
    (function() {
      const revealEls = document.querySelectorAll('.anim-fade-up');
      if (!revealEls.length) return;

      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

      revealEls.forEach(el => observer.observe(el));
    })();
  </script>
</body>
</html>
