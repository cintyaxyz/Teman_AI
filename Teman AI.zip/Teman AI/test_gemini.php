<?php
// Test Gemini API langsung tanpa session
require_once __DIR__ . '/config.php';

$apiKey = GEMINI_API_KEY;
$model = GEMINI_MODEL;

echo "=== TEST GEMINI API ===\n";
echo "Model: $model\n";

$url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . urlencode($apiKey);
$payload = [
    'contents' => [
        ['role' => 'user', 'parts' => [['text' => 'Halo! Jawab dalam 1 kalimat ramah.']]]
    ]
];

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT => 20,
    CURLOPT_SSL_VERIFYPEER => false
]);
$res = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

echo "HTTP Code: $code\n";
if ($err) echo "cURL Error: $err\n";

$d = json_decode($res, true);
if ($code === 200) {
    echo "SUKSES: " . ($d['candidates'][0]['content']['parts'][0]['text'] ?? '') . "\n";
} else {
    echo "GAGAL: " . ($d['error']['message'] ?? $res) . "\n";
}
